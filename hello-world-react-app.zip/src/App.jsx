import React from 'react'

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '20%' }}>
      <h1>Hello World</h1>
      <p>This is a basic React app showing a 'Hello World' message.</p>
    </div>
  )
}

export default App
